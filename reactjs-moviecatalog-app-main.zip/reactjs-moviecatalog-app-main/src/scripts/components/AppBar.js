import React from 'react';
const AppBar = (props) => {
  return (
    <div className="card-1">
      <h1> {props.title} </h1>
    </div>
  );
};

export default AppBar;
